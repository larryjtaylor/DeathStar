-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Jul 27, 2017 at 10:09 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `death_star`
--
CREATE DATABASE IF NOT EXISTS `death_star` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `death_star`;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL,
  `dept_name` varchar(50) DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `dept_name`, `division_id`) VALUES
(1, 'Army Officers', 1),
(2, 'Army Troopers', 1),
(3, 'Navy Officers', 2),
(4, 'Navy Troopers', 2),
(5, 'Gunners', 3),
(6, 'Battle Station Troopers', 3),
(7, 'Support/Maintenance', 3),
(8, 'Security', 3),
(9, 'Stormtroopers', 4),
(10, 'Pilots', 2);

-- --------------------------------------------------------

--
-- Table structure for table `departments_employees`
--

CREATE TABLE `departments_employees` (
  `id` bigint(20) unsigned NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments_employees`
--

INSERT INTO `departments_employees` (`id`, `department_id`, `employee_id`) VALUES
(1, 3, 6),
(2, 10, 7),
(3, 5, 8),
(4, 6, 9),
(5, 7, 10),
(6, 8, 11),
(7, 5, 12),
(8, 2, 13),
(9, 2, 14),
(10, 1, 15),
(11, 1, 16),
(12, 3, 17),
(13, 10, 18),
(14, 7, 19),
(15, 1, 20),
(16, 1, 21),
(17, 1, 22),
(18, 1, 23),
(19, 1, 24),
(20, 1, 25),
(21, 1, 26),
(22, 1, 27),
(23, 1, 28),
(24, 1, 29),
(25, 1, 30),
(26, 2, 31),
(27, 2, 32),
(28, 2, 33),
(29, 2, 34),
(30, 2, 35),
(31, 2, 36),
(32, 2, 37),
(33, 3, 38),
(34, 3, 39),
(35, 3, 40),
(36, 10, 41),
(37, 10, 42),
(38, 9, 43),
(39, 1, 21),
(40, 2, 21),
(41, 1, 44),
(42, 2, 44),
(43, 2, 20),
(44, 2, 22),
(45, 5, 39),
(46, 9, 45),
(47, 9, 46),
(48, 9, 47),
(49, 9, 48),
(50, 9, 49),
(51, 9, 50),
(52, 9, 51),
(53, 9, 52),
(54, 9, 53),
(55, 9, 54),
(56, 5, 55),
(57, 5, 56),
(58, 5, 57),
(59, 5, 58),
(60, 6, 59),
(61, 8, 60),
(62, 7, 61),
(63, 1, 62),
(64, 2, 26),
(65, 2, 63),
(66, 5, 64),
(67, 6, 65),
(68, 8, 66),
(69, 7, 67),
(70, 3, 68),
(71, 4, 68),
(72, 3, 69),
(73, 10, 70),
(74, 9, 71),
(75, 6, 72),
(76, 6, 73),
(77, 6, 74),
(78, 6, 75),
(79, 6, 76),
(80, 6, 77),
(81, 6, 78),
(82, 8, 79),
(83, 8, 80),
(84, 8, 81),
(85, 8, 82),
(86, 7, 83),
(87, 7, 84),
(88, 7, 85),
(89, 7, 86),
(90, 7, 87),
(91, 7, 88),
(92, 7, 89),
(93, 7, 90),
(94, 5, 91),
(95, 3, 92),
(96, 10, 93),
(97, 10, 94),
(98, 10, 95),
(99, 10, 96);

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `id` bigint(20) unsigned NOT NULL,
  `div_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `div_name`) VALUES
(1, 'Army'),
(2, 'Navy'),
(3, 'Battle Station'),
(4, 'Imperial');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `rank` varchar(50) DEFAULT NULL,
  `species` varchar(50) DEFAULT NULL,
  `pay` int(11) DEFAULT NULL,
  `record` text
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `rank`, `species`, `pay`, `record`) VALUES
(20, 'Caine', 'Major', 'Cerean', 50000, 'Excellent'),
(22, 'Dur', 'Lieutenant', 'Gand', 35000, 'Average'),
(23, 'Genna', 'Lieutenant', 'Bothan', 35000, 'Excellent'),
(24, 'Mezer', 'Major', 'Duros', 50000, 'Distinguished Service Medal'),
(25, 'Denjax', 'Major', 'Human', 50000, 'Excellent'),
(26, 'Harval', 'Lieutenant', 'Sullustan', 35000, 'Poor'),
(27, 'Rorf', 'Lieutenant', 'Rodian', 35000, 'Excellent'),
(28, 'Baritt', 'Major', 'Bith', 50000, 'Distinguished Service Medal'),
(29, 'Loreza', 'Lieutenant', 'Bith', 35000, 'Average'),
(30, 'PRA7', 'Officer Assistant', 'Protocol Droid', 0, 'Excellent'),
(31, 'Reech', 'Private', 'Qarren', 15000, 'Good'),
(32, 'Danyar', 'Private', 'Mrlssi', 15000, 'Average'),
(33, 'Ben', 'Private', 'Human', 15000, 'Excellent'),
(34, 'B1', 'NA', 'Standard Battle Droid', 0, 'Excellent'),
(35, 'B1', 'NA', 'Standard Battle Droid', 0, 'Excellent'),
(36, 'B2', 'NA', 'Advanced Battle Droid', 0, 'Excellent'),
(37, 'HK-47', 'NA', 'Assassin Droid', 0, 'Excellent'),
(38, 'Laan', 'Lieutenant Commander', 'Human', 35000, 'Distinguished Service Medal'),
(39, 'Ulen', 'Commander', 'Human', 50000, 'Excellent'),
(40, 'LRA7', 'NA', 'Protocol Droid', 0, 'Excellent'),
(41, 'Evian', 'Chief Petty Officer', 'Human', 20000, 'Distinguished Service Medal'),
(42, 'T7', 'NA', 'Astromech Droid', 0, 'Excellent'),
(43, 'DG-4100', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Excellent'),
(44, 'Vara', 'Major', 'Human', 50000, 'Excellent'),
(45, 'TI-8459', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Fair'),
(46, 'MK-2712', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Good'),
(47, 'JY-1475', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Poor'),
(48, 'LV-0942', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Medal of Valor'),
(50, 'DL-2744', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Purple Heart'),
(51, 'DL-2745', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Distinguished Service Medal'),
(52, 'DL-2746', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Excellent'),
(53, 'LV-0943', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Purple Heart'),
(54, 'JY-1476', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Good'),
(55, 'Kamu', 'Private', 'Human', 10000, 'Good'),
(56, 'Pulein', 'Private', 'Bothan', 10000, 'Good'),
(57, 'Liel', 'Private', 'Sullustan', 10000, 'Purple Heart'),
(58, 'Morthous', 'Private', 'Gand', 10000, 'Distinguished Service Medal'),
(59, 'Noola', 'Private', 'Bith', 10000, 'Good'),
(60, 'Cheldra', 'Sergeant', 'Bith', 20000, 'Excellent'),
(61, 'Juisu', 'Private', 'Human', 5000, 'Excellent'),
(72, 'Kuust', 'Private', 'Duros', 15000, 'Medal of Honor'),
(73, 'Jantii', 'Private', 'Human', 15000, 'Good'),
(74, 'Yves', 'Private', 'Verpine', 15000, 'Purple Heart'),
(75, 'Droideka', 'NA', 'Destroyer Droid', 0, 'Excellent'),
(76, 'Droideka', 'NA', 'Destroyer Droid', 0, 'Excellent'),
(77, 'YVH 1', 'NA', 'Advanced Battle Droid', 0, 'Excellent'),
(78, 'B2 Super Battle Droid', 'NA', 'Advanced Battle Droid', 0, 'Excellent'),
(79, 'Rosheth', 'Sergeant', 'Human', 20000, 'Excellent'),
(80, 'Possti', 'Sergeant', 'Human', 20000, 'Average'),
(81, 'Henth', 'Sergeant', 'Human', 20000, 'Poor'),
(82, 'URA7', 'NA', 'Protocol Droid', 0, 'Excellent'),
(83, 'T1', 'NA', 'T1 Loader Droid', 0, 'Excellent'),
(84, 'T1', 'NA', 'T1 Loader Droid', 0, 'Excellent'),
(85, 'T3', 'NA', 'T3 Repair Droid', 0, 'Excellent'),
(86, 'MSE-6', 'NA', 'MSE-6 General Service Droid', 0, 'Excellent'),
(87, 'GH-7', 'NA', 'GH-7 General Medical Droid', 0, 'Excellent'),
(88, 'DD-13', 'NA', 'DD-13 Surgical Droid', 0, 'Excellent'),
(89, 'Uuyrth', 'Private', 'Cerean', 5000, 'Good'),
(90, 'Amorta', 'Private', 'Rodian', 5000, 'Excellent'),
(91, 'DP-2', 'NA', 'Dp-2 Scout/Probe Droid', 0, 'Excellent'),
(92, 'O3PO', 'NA', 'Protocol Droid', 0, 'Excellent'),
(93, 'Lierla', 'Commander', 'Human', 40000, 'Distinguished Service Medal'),
(94, 'Rintsa', 'Lieutenant Commander', 'Human', 45000, 'Medal of Valor'),
(95, 'T7', 'NA', 'T7 Astromech Droid', 0, 'Excellent'),
(96, 'T7', 'NA', 'T7 Astromech Droid', 0, 'Excellent');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `departments_employees`
--
ALTER TABLE `departments_employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `departments_employees`
--
ALTER TABLE `departments_employees`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=100;
--
-- AUTO_INCREMENT for table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=97;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
