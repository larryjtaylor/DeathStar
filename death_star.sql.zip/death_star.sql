-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Jul 27, 2017 at 01:32 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `death_star`
--
CREATE DATABASE IF NOT EXISTS `death_star` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `death_star`;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL,
  `dept_name` varchar(50) DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `dept_name`, `division_id`) VALUES
(1, 'Army Officers', 1),
(2, 'Army Troopers', 1),
(3, 'Navy Officers', 2),
(4, 'Navy Troopers', 2),
(5, 'Gunners', 3),
(6, 'Battle Station Troopers', 3),
(7, 'Support/Maintenance', 3),
(8, 'Security', 3),
(9, 'Stormtroopers', 4),
(10, 'Pilots', 2);

-- --------------------------------------------------------

--
-- Table structure for table `departments_employees`
--

CREATE TABLE `departments_employees` (
  `id` bigint(20) unsigned NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments_employees`
--

INSERT INTO `departments_employees` (`id`, `department_id`, `employee_id`) VALUES
(1, 3, 6),
(2, 10, 7),
(3, 5, 8),
(4, 6, 9),
(5, 7, 10),
(6, 8, 11),
(7, 5, 12),
(8, 2, 13),
(9, 2, 14),
(10, 1, 15),
(11, 1, 16),
(12, 3, 17),
(13, 10, 18),
(14, 7, 19),
(15, 1, 20),
(16, 1, 21),
(17, 1, 22),
(18, 1, 23),
(19, 1, 24),
(20, 1, 25),
(21, 1, 26),
(22, 1, 27),
(23, 1, 28),
(24, 1, 29),
(25, 1, 30),
(26, 2, 31),
(27, 2, 32),
(28, 2, 33),
(29, 2, 34),
(30, 2, 35),
(31, 2, 36),
(32, 2, 37),
(33, 3, 38),
(34, 3, 39),
(35, 3, 40),
(36, 10, 41),
(37, 10, 42),
(38, 9, 43),
(39, 1, 21),
(40, 2, 21),
(41, 1, 44),
(42, 2, 44),
(43, 2, 20),
(44, 2, 22),
(45, 5, 39),
(46, 9, 45),
(47, 9, 46),
(48, 9, 47),
(49, 9, 48),
(50, 9, 49),
(51, 9, 50),
(52, 9, 51),
(53, 9, 52),
(54, 9, 53),
(55, 9, 54),
(56, 5, 55),
(57, 5, 56),
(58, 5, 57),
(59, 5, 58),
(60, 6, 59),
(61, 8, 60),
(62, 7, 61);

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `id` bigint(20) unsigned NOT NULL,
  `div_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `div_name`) VALUES
(1, 'Army'),
(2, 'Navy'),
(3, 'Battle Station'),
(4, 'Imperial');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `rank` varchar(50) DEFAULT NULL,
  `species` varchar(50) DEFAULT NULL,
  `pay` int(11) DEFAULT NULL,
  `record` text
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `rank`, `species`, `pay`, `record`) VALUES
(20, 'Caine', 'Major', 'Cerean', 50000, 'Excellent'),
(22, 'Dur', 'Lieutenant', 'Gand', 35000, 'Average'),
(23, 'Genna', 'Lieutenant', 'Bothan', 35000, 'Excellent'),
(24, 'Mezer', 'Major', 'Duros', 50000, 'Distinguished Service Medal'),
(25, 'Denjax', 'Major', 'Human', 50000, 'Excellent'),
(26, 'Harval', 'Lieutenant', 'Sullustan', 35000, 'Poor'),
(27, 'Rorf', 'Lieutenant', 'Rodian', 35000, 'Excellent'),
(28, 'Barrit', 'Major', 'Bith', 50000, 'Distinguished Service Medal'),
(29, 'Loreza', 'Lieutenant', 'Bith', 35000, 'Average'),
(30, 'PRA7', 'Officer Assistant', 'Protocol Droid', 0, 'Excellent'),
(31, 'Reech', 'Private', 'Qarren', 15000, 'Good'),
(32, 'Danyar', 'Private', 'Mrlssi', 15000, 'Average'),
(33, 'Ben', 'Private', 'Human', 15000, 'Excellent'),
(34, 'B1', 'NA', 'Standard Battle Droid', 0, 'Excellent'),
(35, 'B1', 'NA', 'Standard Battle Droid', 0, 'Excellent'),
(36, 'B2', 'NA', 'Advanced Battle Droid', 0, 'Excellent'),
(37, 'HK-47', 'NA', 'Assassin Droid', 0, 'Excellent'),
(38, 'Lan', 'Lieutenant Commander', 'Human', 35000, 'Distinguished Service Medal'),
(39, 'Ulen', 'Commander', 'Human', 50000, 'Excellent'),
(40, 'LRA7', 'NA', 'Protocol Droid', 0, 'Excellent'),
(41, 'Evian', 'Chief Petty Officer', 'Human', 20000, 'Distinguished Service Medal'),
(42, 'T7', 'NA', 'Astromech Droid', 0, 'Excellent'),
(43, 'DG-4100', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Excellent'),
(44, 'Vara', 'Major', 'Human', 50000, 'Excellent'),
(45, 'TI-8459', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Fair'),
(46, 'MK-2712', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Good'),
(47, 'JY-1475', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Poor'),
(48, 'LV-0942', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Medal of Valor'),
(50, 'DL-2744', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Purple Heart'),
(51, 'DL-2745', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Distinguished Service Medal'),
(52, 'DL-2746', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Excellent'),
(53, 'LV-0943', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Purple Heart'),
(54, 'JY-1476', 'Sergeant', 'Clone - (Jango Fett)', 10000, 'Good'),
(55, 'Kamu', 'Private', 'Human', 10000, 'Good'),
(56, 'Pulein', 'Private', 'Bothan', 10000, 'Good'),
(57, 'Liel', 'Private', 'Sullustan', 10000, 'Purple Heart'),
(58, 'Morthous', 'Private', 'Gand', 10000, 'Distinguished Service Medal'),
(59, 'Noola', 'Private', 'Bith', 10000, 'Good'),
(60, 'Cheldra', 'Sergeant', 'Bith', 20000, 'Excellent'),
(61, 'Juisu', 'Private', 'Human', 5000, 'Excellent');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `departments_employees`
--
ALTER TABLE `departments_employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `departments_employees`
--
ALTER TABLE `departments_employees`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=62;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
