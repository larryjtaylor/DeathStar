-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Jul 26, 2017 at 01:27 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `death_star`
--
CREATE DATABASE IF NOT EXISTS `death_star` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `death_star`;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL,
  `dept_name` varchar(50) DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `dept_name`, `division_id`) VALUES
(1, 'Army Officers', 1),
(2, 'Army Troopers', 1),
(3, 'Navy Officers', 2),
(4, 'Navy Troopers', 2),
(5, 'Gunners', 3),
(6, 'Battle Station Troopers', 3),
(7, 'Support/Maintenance', 3),
(8, 'Security', 3),
(9, 'Stormtroopers', 4),
(10, 'Pilots', 2);

-- --------------------------------------------------------

--
-- Table structure for table `departments_employees`
--

CREATE TABLE `departments_employees` (
  `id` bigint(20) unsigned NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments_employees`
--

INSERT INTO `departments_employees` (`id`, `department_id`, `employee_id`) VALUES
(1, 3, 6),
(2, 10, 7),
(3, 5, 8),
(4, 6, 9),
(5, 7, 10),
(6, 8, 11),
(7, 5, 12),
(8, 2, 13),
(9, 2, 14),
(10, 1, 15),
(11, 1, 16),
(12, 3, 17),
(13, 10, 18),
(14, 7, 19),
(15, 1, 20),
(16, 1, 21),
(17, 1, 22),
(18, 1, 23),
(19, 1, 24),
(20, 1, 25),
(21, 1, 26),
(22, 1, 27),
(23, 1, 28),
(24, 1, 29),
(25, 1, 30),
(26, 2, 31),
(27, 2, 32),
(28, 2, 33),
(29, 2, 34),
(30, 2, 35),
(31, 2, 36),
(32, 2, 37),
(33, 3, 38),
(34, 3, 39),
(35, 3, 40),
(36, 10, 41),
(37, 10, 42);

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `id` bigint(20) unsigned NOT NULL,
  `div_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `div_name`) VALUES
(1, 'Army'),
(2, 'Navy'),
(3, 'Battle Station'),
(4, 'Imperial');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `rank` varchar(50) DEFAULT NULL,
  `species` varchar(50) DEFAULT NULL,
  `pay` int(11) DEFAULT NULL,
  `record` text
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `rank`, `species`, `pay`, `record`) VALUES
(8, 'Caine', 'Extroardinaire', 'Human', 323, 'Excellent'),
(9, 'Calla', 'Major', 'Bothan', -2, 'Distinguished Service Medal'),
(11, 'Caine', 'Extroardinaire', 'Human', -4, 'Excellent'),
(12, 'Jonas', 'Major', 'kinda human', 32424, 'Distinguished Service Medal'),
(20, 'Caine', 'Major', 'Cerean', 50000, 'Excellent'),
(21, 'Vara', 'Major', 'Rodian', 50000, 'Good'),
(22, 'Dur', 'Lieutenant', 'Gand', 35000, 'Average'),
(23, 'Genna', 'Lieutenant', 'Bothan', 35000, 'Excellent'),
(24, 'Mezer', 'Major', 'Duros', 50000, 'Distinguished Service Medal'),
(25, 'Denjax', 'Major', 'Human', 50000, 'Excellent'),
(26, 'Harval', 'Lieutenant', 'Sullustan', 35000, 'Poor'),
(27, 'Rorf', 'Lieutenant', 'Rodian', 35000, 'Excellent'),
(28, 'Barit', 'Lieutenant', 'Tdoshok', 35000, 'Excellent'),
(29, 'Loreza', 'Lieutenant', 'Bith', 35000, 'Average'),
(30, 'PRA7', 'Officer Assistant', 'Protocol Droid', 0, 'Excellent'),
(31, 'Reech', 'Private', 'Qarren', 15000, 'Good'),
(32, 'Danyar', 'Private', 'Mrlssi', 15000, 'Average'),
(33, 'Ben', 'Private', 'Human', 15000, 'Excellent'),
(34, 'B1', 'NA', 'Standard Battle Droid', 0, 'Excellent'),
(35, 'B1', 'NA', 'Standard Battle Droid', 0, 'Excellent'),
(36, 'B2', 'NA', 'Advanced Battle Droid', 0, 'Excellent'),
(37, 'HK-47', 'NA', 'Assassin Droid', 0, 'Excellent'),
(38, 'Lan', 'Lieutenant Commander', 'Human', 35000, 'Distinguished Service Medal'),
(39, 'Ulen', 'Commander', 'Human', 50000, 'Excellent'),
(40, 'LRA7', 'NA', 'Protocol Droid', 0, 'Excellent'),
(41, 'Evan', 'Chief Petty Officer', 'Human', 20000, 'Distinguished Service Medal'),
(42, 'T7', 'NA', 'Astromech Droid', 0, 'Excellent');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `departments_employees`
--
ALTER TABLE `departments_employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `departments_employees`
--
ALTER TABLE `departments_employees`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
